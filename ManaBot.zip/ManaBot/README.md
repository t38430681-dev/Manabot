# Mana Bot (Android)
Joga o puzzle "Mana Control" (Roblox) sozinho: lê a tela (MediaProjection), mede o círculo e segura/solta a tela (AccessibilityService).

## Gerar o APK
- GitHub: crie um repositório, suba esta pasta, aba Actions > "Build APK" > baixe o artefato `ManaBot-apk`.
- Ou Android Studio: abrir a pasta e Build > Build APK.

## Usar
1. Instale, abra o app, faça os passos 1, 2 e 3 (aceite a captura de tela).
2. Abra o Roblox no puzzle. Toque na caixinha flutuante: ON/OFF. A caixinha mostra T, R, gap e SEGURA/solta.
3. Se não ler (sempre "sem leitura"), ajuste "Centro do círculo X/Y" até ficar sobre o centro do círculo.
