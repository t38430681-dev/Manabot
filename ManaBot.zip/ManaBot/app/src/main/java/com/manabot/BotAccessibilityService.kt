package com.manabot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/** Segura/solta a tela encadeando traços contínuos (continueStroke). */
class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
        private const val SEG_MS = 40L
    }

    private val main = Handler(Looper.getMainLooper())
    private var stroke: StrokeDescription? = null
    private var busy = false
    @Volatile private var wantHold = false
    var x = 0f; var y = 0f

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { setHold(false) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun setHold(h: Boolean) { wantHold = h; main.post { pump() } }

    private fun path(): Path = Path().apply { moveTo(x, y) }

    private fun pump() {
        if (busy) return
        val s = stroke
        val next: StrokeDescription = when {
            s == null && wantHold -> StrokeDescription(path(), 0, SEG_MS, true)
            s != null && wantHold -> s.continueStroke(path(), 0, SEG_MS, true)
            s != null && !wantHold -> s.continueStroke(path(), 0, 1, false)
            else -> return
        }
        val ending = !next.willContinue()
        busy = true
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(next).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    stroke = if (ending) null else next
                    busy = false; pump()
                }
                override fun onCancelled(g: GestureDescription?) {
                    stroke = null; busy = false; pump()
                }
            }, null
        )
        if (!ok) { busy = false; stroke = null }
        else if (!ending) stroke = next
    }
}
