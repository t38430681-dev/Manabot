package com.manabot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val REQ = 42
    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, 24, 0, 4) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        root.addView(TextView(this).apply {
            text = "Mana Bot — Mana Control\n1) acessibilidade  2) sobreposição  3) iniciar captura. " +
                "Abra o Roblox no puzzle e toque na caixinha flutuante para ligar/desligar. Arraste para mover."
        })
        root.addView(btn("1. Ativar serviço de acessibilidade") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("2. Permitir sobreposição") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("3. Iniciar captura + caixinha") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        })
        root.addView(btn("Parar") { startService(Intent(this, CaptureService::class.java).setAction("STOP")) })

        fun slider(name: String, key: String, min: Float, max: Float, def: Float, unit: String) {
            val v = prefs.getFloat(key, def)
            val tv = label("$name: ${"%.1f".format(v)}$unit")
            val sb = SeekBar(this).apply {
                this.max = 200; progress = (((v - min) / (max - min)) * 200).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                        val nv = min + (max - min) * p / 200f
                        prefs.edit().putFloat(key, nv).apply(); tv.text = "$name: ${"%.1f".format(nv)}$unit"
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            root.addView(tv); root.addView(sb)
        }
        slider("Gap alvo (T-R)", "gap", 30f, 70f, 48f, " px")
        slider("Antecipação", "lead", 0f, 300f, 120f, " ms")
        slider("Centro do círculo X", "cx", 44f, 56f, 49.9f, " %")
        slider("Centro do círculo Y", "cy", 44f, 56f, 49.8f, " %")
        slider("Ponto de toque X", "tx", 55f, 78f, 68f, " %")
        slider("Ponto de toque Y", "ty", 45f, 80f, 60f, " %")
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rc: Int, data: Intent?) {
        super.onActivityResult(rq, rc, data)
        if (rq == REQ && rc == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", rc).putExtra("data", data))
            Toast.makeText(this, "Abra o Roblox e toque na caixinha para ligar", Toast.LENGTH_LONG).show()
        }
    }
}
