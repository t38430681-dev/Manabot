package com.manabot

import java.nio.ByteBuffer

/**
 * Lê UMA linha horizontal (3 linhas médias) passando pelo centro do círculo e acha:
 *  - T: círculo fino mais externo (borda do disco de mana — é ele que você controla:
 *       segurar encolhe, soltar expande);
 *  - R: anel grosso (duas bordas) mais externo, que vira dourado quando "acerta".
 * Medido nos seus vídeos: o anel fica dourado ~90% das vezes quando T - R está entre ~38 e ~58 px
 * (em frame de 1068 px de largura).
 */
object Detector {
    class Reading(val t: Float, val r: Float, val gold: Boolean)
    private class Run(val c: Float, val w: Int, val gold: Boolean)

    const val FRAME_W = 1068

    fun analyze(
        buf: ByteBuffer, rowStride: Int, pixStride: Int, w: Int, h: Int,
        cxFrac: Float, cyFrac: Float
    ): Reading? {
        val cx = (cxFrac * w).toInt()
        val cy = (cyFrac * h).toInt().coerceIn(1, h - 2)
        val rmax = 140
        if (cx - rmax < 0 || cx + rmax >= w) return null
        val ts = ArrayList<Float>(2); val rs = ArrayList<Float>(2); var gold = false
        for (sgn in intArrayOf(-1, 1)) {
            val n = rmax - 8
            val bright = BooleanArray(n); val gd = BooleanArray(n)
            for (i in 0 until n) {
                val x = cx + sgn * (i + 8)
                var rr = 0; var gg = 0; var bb = 0
                for (dy in -1..1) {
                    val o = (cy + dy) * rowStride + x * pixStride
                    rr += buf.get(o).toInt() and 255
                    gg += buf.get(o + 1).toInt() and 255
                    bb += buf.get(o + 2).toInt() and 255
                }
                rr /= 3; gg /= 3; bb /= 3
                val isGold = rr > 200 && gg > 140 && bb < 120
                gd[i] = isGold
                bright[i] = isGold || minOf(rr, gg, bb) > 190
            }
            val runs = ArrayList<Run>()
            var i = 0
            while (i < n) {
                if (bright[i]) {
                    var j = i
                    while (j + 1 < n && bright[j + 1]) j++
                    var g = false
                    for (k in i..j) if (gd[k]) g = true
                    runs.add(Run((i + j) / 2f + 8f, j - i + 1, g))
                    i = j + 1
                } else i++
            }
            var t = -1f; var r = -1f; var g = false
            for (run in runs) {
                if (run.w <= 2 && run.c in 20f..132f && run.c > t) t = run.c
                if (run.w >= 3 && run.c in 20f..125f) { if (run.c > r) r = run.c; if (run.gold) g = true }
            }
            if (t > 0 && r > 0) { ts.add(t); rs.add(r); gold = gold || g }
        }
        if (ts.isEmpty()) return null
        return Reading(ts.average().toFloat(), rs.average().toFloat(), gold)
    }
}
