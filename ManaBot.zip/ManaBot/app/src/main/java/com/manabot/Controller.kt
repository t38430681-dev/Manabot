package com.manabot

/**
 * Objetivo: manter  gap = T - R  perto de targetGap (anel dourado).
 * Medido nos vídeos: SEGURAR => T encolhe (~-6 px/s), SOLTAR => T expande (~+5 px/s); R quase não reage.
 * Então: gap acima do alvo => segurar; abaixo => soltar. Usa derivada para antecipar (lead).
 * "SURGE" só muda a deriva de T; o controle em malha fechada compensa sozinho.
 */
class Controller {
    var targetGap = 48f
    var leadSec = 0.12f
    private var hold = false
    private var lastGap = Float.NaN
    private var lastT = 0L
    private var dGap = 0f
    private var lastSeen = 0L
    var lastError = 0f; private set

    fun update(rd: Detector.Reading?, now: Long): Boolean {
        if (rd == null) {
            if (now - lastSeen > 250) hold = false   // sem leitura: solta (deixa expandir)
            return hold
        }
        lastSeen = now
        val gap = rd.t - rd.r
        if (!lastGap.isNaN() && now > lastT) {
            val d = (gap - lastGap) / ((now - lastT) / 1000f)
            dGap = 0.6f * dGap + 0.4f * d.coerceIn(-80f, 80f)
        }
        lastGap = gap; lastT = now
        val e = gap + leadSec * dGap - targetGap
        lastError = e
        if (e > 1.5f) hold = true else if (e < -1.5f) hold = false
        return hold
    }

    fun reset() { hold = false; lastGap = Float.NaN; dGap = 0f }
}
