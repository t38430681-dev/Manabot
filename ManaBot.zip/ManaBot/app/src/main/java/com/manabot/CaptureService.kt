package com.manabot

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var thread: HandlerThread
    private val controller = Controller()
    private var overlay: TextView? = null
    private var wm: WindowManager? = null
    @Volatile private var enabled = false
    private var lastCfg = 0L
    private var cx = 0.499f; private var cy = 0.498f
    private var tx = 0.68f; private var ty = 0.60f
    private var frames = 0; private var lastUi = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mana", "Mana Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "mana").setContentTitle("Mana Bot ativo")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        thread = HandlerThread("mana-cap").also { it.start() }
        val handler = Handler(thread.looper)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        // Sempre paisagem: lado maior = largura. Em retrato o conteúdo aparece pequeno até o Roblox girar a tela.
        val dm = resources.displayMetrics
        val long = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
        val short = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        val w = Detector.FRAME_W
        val h = (w * short / long).toInt()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay(
            "mana", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        reader!!.setOnImageAvailableListener({ r -> onFrame(r, w, h) }, handler)
        showOverlay()
        return START_NOT_STICKY
    }

    private fun loadCfg() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        controller.targetGap = p.getFloat("gap", 48f)
        controller.leadSec = p.getFloat("lead", 120f) / 1000f
        cx = p.getFloat("cx", 49.9f) / 100f; cy = p.getFloat("cy", 49.8f) / 100f
        tx = p.getFloat("tx", 68f) / 100f; ty = p.getFloat("ty", 60f) / 100f
    }

    private fun onFrame(r: ImageReader, w: Int, h: Int) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastCfg > 700) { loadCfg(); lastCfg = now }
            val pl = img.planes[0]
            val rd = Detector.analyze(pl.buffer, pl.rowStride, pl.pixelStride, w, h, cx, cy)
            val svc = BotAccessibilityService.instance
            val hold: Boolean
            if (enabled) {
                hold = controller.update(rd, now)
                val dm = resources.displayMetrics
                val lw = maxOf(dm.widthPixels, dm.heightPixels); val lh = minOf(dm.widthPixels, dm.heightPixels)
                svc?.x = tx * lw; svc?.y = ty * lh
                svc?.setHold(hold)
            } else { hold = false; controller.reset(); svc?.setHold(false) }
            frames++
            if (now - lastUi > 150) {
                lastUi = now
                val txt = (if (enabled) "ON " else "OFF") + (if (svc == null) " (sem acessib.)" else "") +
                    if (rd != null) " T=%.0f R=%.0f gap=%.0f %s%s".format(rd.t, rd.r, rd.t - rd.r,
                        if (hold) "SEGURA" else "solta", if (rd.gold) " *" else "") else " sem leitura"
                overlay?.post { overlay?.text = txt }
            }
        } finally { img.close() }
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "OFF"; textSize = 11f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xCC222222.toInt())
            setPadding(16, 10, 16, 10)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 200; y = 120 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) > 12 || Math.abs(e.rawY - sy) > 12) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm?.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { enabled = !enabled }   // toque = liga/desliga
            }
            true
        }
        try { wm!!.addView(tv, lp); overlay = tv } catch (e: Exception) { stopSelf() }
    }

    override fun onDestroy() {
        BotAccessibilityService.instance?.setHold(false)
        overlay?.let { wm?.removeView(it) }
        vd?.release(); reader?.close(); projection?.stop()
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }
}
